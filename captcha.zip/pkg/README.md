# captcha
画像認証向け画像を作成します(wasmで動いています)

## Sample

![oi](./sample.png)
